package co.edu.unbosque.model;

import java.util.ArrayList;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class UsuarioBean {
	
	private Integer id;
	private String cedula_usuario;
	private String nombre_usuario;
	private String email_usuario;
	private String usuario;
	private String password;
	private String resultado;
	
	private ArrayList<UsuarioDTO> listausuarios;
	
	public String agregar() {
		UsuarioDAO cl = new UsuarioDAO();
		this.resultado = cl.agregar(new UsuarioDTO(
			this.id,
			this.cedula_usuario, 
			this.nombre_usuario,
			this.email_usuario, 
			this.usuario,			
			this.password));
		if(this.resultado.equals("200")) {
			this.listausuarios = (ArrayList<UsuarioDTO>)cl.consultar();
			return "tablausuario.xhtml";
		}
		else {
			return "error.xhtml";
		}
	
	}
	
	public String consultar() {
		UsuarioDAO cl = new UsuarioDAO();
		this.listausuarios = (ArrayList<UsuarioDTO>)cl.consultar();
		if(this.listausuarios!=null) {
			System.out.println(this.listausuarios);
			return "tablausuario.xhtml";
		}
		else {
			return "error.xhtml";
		}		
	}
	
	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}



	public ArrayList<UsuarioDTO> getListausuarios() {
		return listausuarios;
	}



	public void setListausuarios(ArrayList<UsuarioDTO> listausuarios) {
		this.listausuarios = listausuarios;
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCedula_usuario() {
		return cedula_usuario;
	}
	public void setCedula_usuario(String cedula_usuario) {
		this.cedula_usuario = cedula_usuario;
	}
	public String getNombre_usuario() {
		return nombre_usuario;
	}
	public void setNombre_usuario(String nombre_usuario) {
		this.nombre_usuario = nombre_usuario;
	}
	public String getEmail_usuario() {
		return email_usuario;
	}
	public void setEmail_usuario(String email_usuario) {
		this.email_usuario = email_usuario;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
