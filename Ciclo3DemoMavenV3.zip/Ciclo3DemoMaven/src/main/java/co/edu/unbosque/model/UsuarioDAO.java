package co.edu.unbosque.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UsuarioDAO implements ICrud{
	
	private ArrayList<UsuarioDTO> listaUsuarios;

	@Override
	public String agregar(Object registro) {
		// TODO Auto-generated method stub
		String mensaje = null;
		int respuesta = 0;
		try {
			respuesta = TestJSON.postJSON((UsuarioDTO) registro);
			mensaje = String.valueOf(respuesta);
			System.out.println("Respuesta:"+mensaje);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
		
		return mensaje;
	}
	

	@Override
	public Object consultar() {
		// TODO Auto-generated method stub
		try {
			listaUsuarios = TestJSON.getJSON();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listaUsuarios;		
	}

	@Override
	public String actualizar(Object id, Object registro) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String eliminar(Object id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object listar() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
